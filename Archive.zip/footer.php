<?php wp_footer(); ?>
<footer id="footer">
	<div class="ng-container">
		<div class="ng-flex">
      <div class="ng-flex__item"><?php dynamic_sidebar( 'footer_1' ); ?></div>
		  <div class="ng-flex__item"><?php dynamic_sidebar( 'footer_2' ); ?></div>
		  <div class="ng-flex__item"><?php dynamic_sidebar( 'footer_3' ); ?></div>
    </div>
  </div>
</footer>
</body>
</html>