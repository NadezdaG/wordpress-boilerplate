https://github.com/NadezdaG/wordpress-boilerplate.git

Copy folder and run 

npm install

inside the terminal.

Use comand 'gulp' to start working on the project.
This set helps to build WP themes: optimise images, minify scripts and compile scss files ;) enjoy!

Don't forget to update gulpfile.js with your details ;)

Nadezda